var pg = {
    
}

module.exports = {
    port:5000, // runing port
    pg:pg, // postgress connection
    baseUrl: '/api/v1',
    enabledDb:'firebase' // pg,firebase
};