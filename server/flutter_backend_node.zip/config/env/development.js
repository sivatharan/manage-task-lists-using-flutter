var pg = {
    
}

module.exports = {
    port:9000, // runing port
    pg:pg, // postgress connection
    baseUrl: '/api/v1',
    enabledDb:'mysql' // pg,firebase
};