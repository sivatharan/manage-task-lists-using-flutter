create db name as test;
import the sql file
npm install - install dependencies
npm start - start the node server
